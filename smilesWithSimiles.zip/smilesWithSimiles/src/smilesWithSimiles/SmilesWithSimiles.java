package smilesWithSimiles;


import java.util.ArrayList;
import java.util.Scanner;

public class SmilesWithSimiles {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int adjNum = scn.nextInt();
		int nounNum = scn.nextInt();
		
		ArrayList<String> adjectives = new ArrayList<>();
		for (int i = 0; i < adjNum+1; i++){
			adjectives.add(scn.nextLine());
		}
		ArrayList<String> nouns = new ArrayList<>();
		for (int i = 0; i < nounNum; i++){
			nouns.add(scn.nextLine());
		}
		int flag = 0;
		do{
			if (flag == 0){
				flag++;
			}
			else{
			for(int i = 0; i < nouns.size(); i++){
				System.out.println(adjectives.get(flag) + " as " + nouns.get(i));
			}
			flag++;
			}
		}
		while (flag <= adjNum);

	}
}
