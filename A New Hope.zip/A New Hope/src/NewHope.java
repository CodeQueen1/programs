import java.util.Scanner;

public class NewHope {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int far = scn.nextInt() -1;
		String f = " far,";
		String fc = "far";
		String rep = new String(new char[far]).replace("\0", f);
		System.out.println("A long time ago in a galaxy" + rep + " " + fc + " " + " away...");
	}

}
