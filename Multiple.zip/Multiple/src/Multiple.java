import java.util.Scanner;

public class Multiple {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int num1 = scn.nextInt();
		int num2 = scn.nextInt();
		if ((num1 % num2) == 0){
		System.out.println("yes");
	}
		else{
			System.out.println("no");
		}
	}

}
