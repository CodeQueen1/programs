import java.util.Scanner;

public class BodyMassIndex {

	public static void main(String[] args) {
		Scanner scn = new Scanner (System.in);
		double weight = scn.nextDouble();
		double height = scn.nextDouble();
		double bmi = weight / (height * height);
		if (bmi > 25){
			System.out.println("Overweight");
		}
		else if (bmi >= 18.5 && bmi <= 25.0){
			System.out.println("Normal weight");
		}
		else if (bmi < 18.5){
			System.out.println("Underweight");
		}

	}

}
