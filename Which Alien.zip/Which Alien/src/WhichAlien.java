import java.util.Scanner;

public class WhichAlien {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int ant = scn.nextInt();
		int eyes = scn.nextInt();
		if(ant >= 3 && eyes<=4){
			System.out.println("TroyMartian");
		}
		if(ant<=6 && eyes >=2){
			System.out.println("VladSaturnian");
		}
		if(ant <=2 && eyes <=3){
			System.out.println("GraemeMercurian");
		}

	}

}
