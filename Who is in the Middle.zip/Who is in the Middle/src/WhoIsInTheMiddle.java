import java.util.Scanner;

public class WhoIsInTheMiddle {

	public static void main(String[] args) {
		Scanner scn = new Scanner (System.in);
		int[] nums = new int [3];
		for (int i = 0; i < nums.length ; i++){
			nums[i] = scn.nextInt();
		}
		if (nums[0] > nums[1]){
			if(nums[1] > nums[2]){
				System.out.println(nums[1]);
			} else if (nums[0] > nums[2]){
				System.out.println(nums[2]);
			} else {
				System.out.println(nums[0]);
			}
		} else {
			if(nums[0] > nums[2]){
				System.out.println(nums[0]);
			} else  if (nums[1] > nums[2]){
				System.out.println(nums[2]);
			} else {
				System.out.println(nums[1]);
			}
		}
		
	}

}
