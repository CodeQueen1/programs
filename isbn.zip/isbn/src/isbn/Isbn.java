package isbn;

import java.util.Scanner;

public class Isbn {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int num1 = scn.nextInt();
		int num2 = scn.nextInt();
		int num3 = scn.nextInt();
		int sum = num1 + (num2 *3) + num3 + 91;
		System.out.println("The 1-3-sum is " + sum);
	}

}
