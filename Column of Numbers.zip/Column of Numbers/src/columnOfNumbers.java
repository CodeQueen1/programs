import java.util.Scanner;

public class columnOfNumbers {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		String word = scn.nextLine();
		for (int i = word.length()-1; i < word.length() && i >= 0; i--){
			System.out.println(word.charAt(i));
		}

	}

}
