import java.util.Scanner;

public class Speak {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		boolean flag = false;
		do{
			String word = scn.nextLine();
			if(word.equals("CU")){
				System.out.println("see you");
			}
			else if(word.equals(":-)")){
				System.out.println("I'm happy");
			}
			else if(word.equals(":-(")){
				System.out.println("I'm unhappy");
			}
			else if(word.equals(";-)")){
				System.out.println("wink");
			}
			else if(word.equals(":-P")){
				System.out.println("stick out my tongue");
			}
			else if(word.equals("(~.~)")){
				System.out.println("sleepy");
			}
			else if(word.equals("TA")){
				System.out.println("totally awesome");
			}
			else if(word.equals("CCC")){
				System.out.println("Canadian Computing Competition");
			}
			else if(word.equals("CUZ")){
				System.out.println("because");
			}
			else if(word.equals("TY")){
				System.out.println("thank-you");
			}
			else if(word.equals("YW")){
				System.out.println("you're welcome");
			}
			else if(word.equals("TTYL")){
				System.out.println("talk to you later");
				flag = true;
			}
			else{
				System.out.println(word);
			}
		}
		while (flag != true);

	}

}
