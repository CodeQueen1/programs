import java.util.Scanner;

public class AUTORI {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		String nm = scn.nextLine();
		System.out.print(nm.charAt(0));
		for(int i = 0; i <nm.length(); i++){
			if(nm.charAt(i) == '-'){
				System.out.print(nm.charAt(i + 1));
			}
			
		}
	}

}
