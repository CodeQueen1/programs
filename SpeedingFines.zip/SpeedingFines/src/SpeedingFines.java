import java.util.Scanner;

public class SpeedingFines {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int limit = scn.nextInt();
		int speed = scn.nextInt();
		int sum = speed - limit;
		if (speed < limit){
			System.out.println("Congratulations, you are within the speed limit!");
		}
		else if (speed == limit){
			System.out.println("Congratulations, you are within the speed limit!");
		}
		else if(sum>1 && sum < 20 || sum ==1 || sum == 2){
			System.out.println("You are speeding and your fine is $100.");
		}
		else if(sum >21 && sum < 30 || sum == 21 || sum == 30){
			System.out.println("You are speeding and your fine is $270.");
		}
		else if(sum > 31 || sum == 31){
			System.out.println("You are speeding and your fine is $500.");
		}
	}

}
