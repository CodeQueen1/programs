import java.util.Scanner;

public class AmeriCanadian {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		boolean flag = false;
		do{
			String word = scn.nextLine();
			if(word.length() > 65000){
				System.exit(0);
			}
			else if(word.length() > 4 && word.endsWith("or") && word.charAt(index)){
			   System.out.println(word.replace("or", "our"));
			}
			else if (word.equalsIgnoreCase("quit!")){
				System.exit(0);
			}
			else{
				System.out.println(word);
			}
			flag = true;
		}
		while(flag == true);
		

	}

}
