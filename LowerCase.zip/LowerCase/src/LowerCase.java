import java.util.Scanner;

public class LowerCase {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int n = scn.nextInt();
		do{
			String word = scn.nextLine();
			System.out.println(word.toLowerCase());
			n--;
		}
		while(n>=0);

	}

}
