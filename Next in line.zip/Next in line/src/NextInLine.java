import java.util.Scanner;

public class NextInLine {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int a1 = scn.nextInt();
		int a2 = scn.nextInt();
		int sum = a2 - a1;
		System.out.println(a2 + sum);
	}

}
