import java.util.Scanner;

public class Prime {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		
		int l = scn.nextInt();
		
		int m = 0;
		do{
			int k = scn.nextInt();
			if(
			if(k.startsWith("-")){
				System.out.println(k.length()-1);
			}
			else{
				System.out.println(k.length());
			}
			m++;
		}
		while(m<l);
//		do{
//		int perfect_modulo = 0;
//		  boolean prime = false;
//		  int n = scn.nextInt();
//		  for ( int i = 1; i <=  n; i++ ) {
//			  
//		    if ( n % i == 0 ) {
//		      perfect_modulo += 1;
//		    }
//		  }
//		  if ( perfect_modulo == 2 ) {
//		    prime = true;
//		    System.out.println("1");
//		  }
//		  else{
//		  prime = false;
//		  System.out.println("0");
//		  }
//		  m++;
//		}
//		while(m<l);
	}
}
		
		
//		int nums[] = new int[n];
//		for(int i = 0; i < nums.length; i++){
//			nums[i] = scn.nextInt();
//		}
//		int l = 0;
//		do{
//			if (nums[l] == 0 || nums[l] == 1) { 
//				System.out.println( "0"); 
//			} 
//			else if (nums[l] == 2 || nums[l] == 3) { 
//				System.out.println( "1"); 
//			} 
//			else if ((nums[l] * nums[l] - 1) % 24 == 0) { 
//				System.out.println( "1"); 
//			} 
//			else { 
//				System.out.println( "0"); 
//			} 
//			l++;
//		}
//		while(l<n);
//	}




//int sqrt = (int) Math.sqrt(num) + 1;
//for (int i = 2; i < num; i++){
//	if(num%i == 0){
//		System.out.println(0);
//	}
//}
//System.out.println(1);


