import java.util.Scanner;

public class Squares {

	public static void main(String[] args) {
		Scanner scn = new Scanner (System.in);
		double side = scn.nextInt();
		System.out.println("The largest square has side length " + (int)Math.sqrt(side)+".");

	}

}
