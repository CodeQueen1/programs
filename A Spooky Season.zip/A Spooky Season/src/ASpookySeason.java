import java.util.Scanner;

public class ASpookySeason {

	public static void main(String[] args) {
		int loopVal = 0;

		do {
		System.out.println("Printing Some Text");
		loopVal++;
		}
		while ( loopVal < 5 );
	}

}
