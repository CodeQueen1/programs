import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class TheFiveMs {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		 DecimalFormat f = new DecimalFormat("#0.00");
		int num = scn.nextInt();
		double[] mnums = new double[num];
		for(int i = 0; i<mnums.length; i++){
			mnums[i] = scn.nextDouble();
		}
		double mean = 0;
		for(int i = 0; i<mnums.length; i++){
			mean = mean + mnums[i];
		}
		System.out.println(f.format(mean/mnums.length));
		Arrays.sort(mnums);
		double median;
		double middle = mnums.length/2;
		if(mnums.length%2 == 0){
			double median1 = mnums[(int) middle];
			double median2 = mnums[(int) middle -1];
			median = (median1 + median2)/2;
			System.out.println(f.format(median));
		}
		else{
			median = mnums[(int) middle]; // +1
			System.out.println(f.format(median));
		}
		double max = 0;
		double maxCount = 0;
		for(int i = 0; i < mnums.length; i++){
			int count = 0;
			for(int j = 0; j < mnums.length; j++){
				if(mnums[i] == mnums[j]){
					count++;
				}
			}
			if(count>maxCount){
				maxCount = count;
				max = mnums[i];
			}
		}
		System.out.println(f.format(max));
		double maxMax = 0;
		for(int i = 0; i < mnums.length; i++){
			if(mnums[i] > maxMax){
				maxMax = mnums[i];
			}
		}
		System.out.println(f.format(maxMax));
		double min = maxMax;
		for(int i = 0; i < mnums.length; i++){
			if(mnums[i] < min){
				min = mnums[i];
			}
		}
		System.out.println(f.format(min));
	}

}
