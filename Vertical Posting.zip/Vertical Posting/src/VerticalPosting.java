import java.util.Scanner;

public class VerticalPosting {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		char[] words = new char[20];
		String w = scn.nextLine();
		for(int i = 0; i <w.length(); i++){
			words[i] = w.charAt(i);
			System.out.print(w.charAt(i) + " ");
		}
		System.out.println(" ");
		for(int i = 1; i < w.length(); i++){
			System.out.println(w.charAt(i) + " ");
		}
	}

}
