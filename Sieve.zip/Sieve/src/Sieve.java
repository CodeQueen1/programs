import java.util.Scanner;

public class Sieve {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int num = scn.nextInt();		
		int m = 1;
		do{
		int perfect_modulo = 0;
		  boolean prime = false;
		  //int n = 1;
			for (int i = 1; i <= m; i++ ) {
			  
		    if ( m % i == 0 ) {
		      perfect_modulo += 1;
		    }
		  }
		  if ( perfect_modulo == 2 ) {
		    prime = true;
		    System.out.println("1");
		  }
		  else{
		  prime = false;
		  System.out.println("0");
		  }
		  m++;
		}
		while(m<num+1);
	}

	}


