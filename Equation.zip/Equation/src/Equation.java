import java.text.DecimalFormat;
import java.util.Scanner;

public class Equation {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		double a = scn.nextDouble();
		double b = scn.nextDouble();
		if(a == 0 && b == 0){
			System.out.println("indeterminate");
			System.exit(0);
		}
		else if(a == 0 || b == 0){
			System.out.println("undefined");
			System.exit(0);
		}
		double x = (b*-1)/a;
		DecimalFormat f = new DecimalFormat("0.00");
		System.out.println(f.format(x));

	}

}
