import java.util.Scanner;

public class SpecialDay {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int month = scn.nextInt();
		int day = scn.nextInt();
		if (month < 2 && day < 18){
			System.out.println("Before");
		}
		else if (month > 2 && day > 18){
			System.out.println("After");
		}
		else if(month == 2 && day < 18){
			System.out.println("Before");
		}
		else if(month == 2 && day > 18){
			System.out.println("After");
		}
		else if(month < 2 && day == 18){
			System.out.println("Before");
		}
		else if(month > 2 && day == 18){
			System.out.println("After");
		}
		else if(month > 2 && day < 18){
			System.out.println("After");
		}
		else if(month < 2 && day > 18){
			System.out.println("Before");
		}
		else if (month == 2 && day == 18){
			System.out.println("Special");
		}

	}

}
