import java.util.Scanner;

public class Peg416 {

	public static void main(String[] args) {
		Scanner scn = new Scanner (System.in);
		String phone = scn.nextLine();
		if(phone.length() != 11){
			System.out.println("invalid");
		}
		else if(phone.charAt(3) == ' ' ){
			if(phone.startsWith("416")){
				System.out.println("valuable");
			}
			else if(phone.startsWith("647") || phone.startsWith("437")){
				System.out.println("valueless");
			}
			else{
				System.out.println("invalid");
			}
		}
		else{
			System.out.println("invalid");
		}

	}
	}

