import java.util.Scanner;

public class Sorting {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int n = scn.nextInt();
		int[] arr1 = new int [n];
		for(int i = 0; i < n; i++){
			arr1[i] = scn.nextInt();
		}
		int[] arr2 = SelectionSort(arr1);
		for(int i:arr2){
			System.out.println(i);
		}

	}
	
	public static int[] SelectionSort(int[] arr){
        
        for (int i = 0; i < arr.length - 1; i++)
        {
            int index = i;
            for (int j = i + 1; j < arr.length; j++)
                if (arr[j] < arr[index])
                    index = j;
      
            int smallerNumber = arr[index]; 
            arr[index] = arr[i];
            arr[i] = smallerNumber;
        }
        return arr;
    }

	
	
//	public static void SelectionSort ( int [ ] num )
//	{
//	     int i, j, first, temp;  
//	     for ( i = num.length - 1; i > 0; i -- )  
//	     {
//	          first = 0;   //initialize to subscript of first element
//	          for(j = 1; j <= i; j ++)   //locate smallest element between positions 1 and i.
//	          {
//	               if( num[ j ] < num[ first ] )         
//	                 first = j;
//	          }
//	          temp = num[ first ];   //swap smallest found with element in position i.
//	          num[ first ] = num[ i ];
//	          num[ i ] = temp; 
//	      }           
//	}

}
